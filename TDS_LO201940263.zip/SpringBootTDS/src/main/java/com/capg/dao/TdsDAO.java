package com.capg.dao;

import com.capg.dto.TdsMaster;

public interface TdsDAO {
	
	TdsMaster getByPid(int pId);


}
