package com.capg.service;

import com.capg.dto.TdsMaster;

public interface Tds {
	
	TdsMaster getByPid(int pId);


}
